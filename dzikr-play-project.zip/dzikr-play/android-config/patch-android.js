// Dijalankan SETELAH "npx cap add android". Aman dijalankan berulang kali (membuat cadangan *.bak).
const fs=require("fs"),path=require("path");
const root=path.join(__dirname,"..");
const VC=process.env.VERSION_CODE||"1",VN=process.env.VERSION_NAME||"1.0.0",TARGET=36;
function edit(f,fn){
  if(!fs.existsSync(f)){console.log("! Tidak ditemukan: "+f+" (jalankan npx cap add android dulu)");return}
  const a=fs.readFileSync(f,"utf8"),b=fn(a);
  if(a!==b){fs.copyFileSync(f,f+".bak");fs.writeFileSync(f,b);console.log("OK diperbarui: "+path.relative(root,f))}
  else console.log("- tidak ada perubahan: "+path.relative(root,f));
}
edit(path.join(root,"android","variables.gradle"),s=>s.replace(/(compileSdkVersion\s*=\s*)\d+/,"$1"+TARGET).replace(/(targetSdkVersion\s*=\s*)\d+/,"$1"+TARGET));
edit(path.join(root,"android","app","build.gradle"),s=>{
  s=s.replace(/versionCode\s+\d+/,"versionCode "+VC).replace(/versionName\s+"[^"]*"/,'versionName "'+VN+'"');
  if(!s.includes("DZIKR-SIGNING")){
    s=s.replace(/(apply plugin: ['"]com\.android\.application['"])/,"$1\n\n// DZIKR-SIGNING\ndef keystorePropertiesFile = rootProject.file(\"../keystore.properties\")\ndef keystoreProperties = new Properties()\nif (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }");
    s=s.replace(/(release\s*\{\s*\n)/,"$1            if (keystorePropertiesFile.exists()) { signingConfig signingConfigs.release }\n");
    s=s.replace(/(\n\s*)buildTypes\s*\{/,"$1signingConfigs {\n        release {\n            if (keystorePropertiesFile.exists()) {\n                storeFile file(keystoreProperties['storeFile'])\n                storePassword keystoreProperties['storePassword']\n                keyAlias keystoreProperties['keyAlias']\n                keyPassword keystoreProperties['keyPassword']\n            }\n        }\n    }\n$1buildTypes {");
    if(!s.includes("signingConfigs.release"))console.log("! Pola build.gradle berbeda. Ikuti langkah manual di README.");
  }
  return s;
});
edit(path.join(root,"android","app","src","main","AndroidManifest.xml"),s=>{
  if(s.includes("android.permission.VIBRATE"))return s;
  const line='    <uses-permission android:name="android.permission.VIBRATE" />';
  if(/<uses-permission[^>]*INTERNET[^>]*\/>/.test(s))return s.replace(/(<uses-permission[^>]*INTERNET[^>]*\/>)/,"$1\n"+line);
  return s.replace("</manifest>",line+"\n</manifest>");
});
console.log("Selesai. versionCode="+VC+", versionName="+VN+", targetSdk="+TARGET);
