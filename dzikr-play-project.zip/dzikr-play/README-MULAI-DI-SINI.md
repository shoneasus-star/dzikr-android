# Dzikr - proyek siap Play Store

Isi folder:
- `www/index.html` aplikasi versi Play Store (tanpa donasi, tanpa koneksi internet)
- `capacitor.config.json`, `package.json` proyek Capacitor (ID paket: com.sultansuhendra.dzikr)
- `android-config/patch-android.js` mengatur targetSdk 36, versi, dan tanda tangan AAB
- `scripts/` pembuat keystore dan pembuat AAB (sh dan bat)
- `store/` semua bahan Play Console: deskripsi, privacy policy, jawaban Data Safety, panduan tester, ikon 512, grafis fitur, screenshot
- `PLAY-STORE-CHECKLIST.md` status 10 langkah dan hal yang masih Anda butuhkan

Perlu terpasang: Node.js 18+, Android Studio terbaru (dengan Android SDK 36 dan JDK bawaan).

Langkah cepat:
1. `npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/app @capacitor/haptics cordova-plugin-purchase`
2. `npx cap add android`
3. `scripts/create-keystore.sh` (sekali saja), salin `android-config/keystore.properties.example` menjadi `keystore.properties` di folder ini lalu isi password
4. `scripts/build-aab.sh` (Windows: `scripts\build-aab.bat`). Untuk rilis berikutnya: `VERSION_CODE=2 VERSION_NAME=1.0.1 scripts/build-aab.sh`
5. Unggah `android/app/build/outputs/bundle/release/app-release.aab` ke Play Console.

Tombol Back HP: tekan sekali menutup pop up/halaman, tekan dua kali (dalam 2 detik) keluar dari aplikasi. Ini memakai plugin @capacitor/app (sudah ada di perintah npm install di atas); tanpa plugin itu keluarnya bisa butuh tiga kali tekan.

Getar: aplikasi memanggil plugin `@capacitor/haptics` (jembatan ke getaran Android, sudah ada di perintah npm install di atas); bila plugin tidak ada, memakai `navigator.vibrate`. `patch-android.js` juga menambahkan izin VIBRATE ke AndroidManifest.xml sebagai cadangan.

Donasi di build Play: memakai Google Play Billing lewat plugin `cordova-plugin-purchase` (pilihan nominal "Dukung Pengembang"). Panduan lengkap: `store/donasi-google-play.md`. Kartu rekening BSI TIDAK ditampilkan di build Play.

Bahasa: Indonesia dan English, dipilih di Pengaturan.

Untuk mencoba di HP dulu (APK debug): `npx cap open android`, lalu Build > Build APK(s).

Jika skrip patch menulis "Pola build.gradle berbeda": buka `android/app/build.gradle` dan tambahkan sendiri `signingConfigs` yang membaca `keystore.properties`, atau tandatangani AAB lewat Android Studio (Build > Generate Signed Bundle / APK).

Font: build Play memakai font sistem HP (tanpa Google Fonts) agar tidak ada permintaan jaringan. Tulisan Arab memakai Noto Naskh bawaan Android. Ingin tampilan persis pratinjau (Amiri, Fraunces, Nunito)? Unduh font bebas (lisensi OFL) dan pasang lewat @font-face di www/index.html.

Catatan: paket ini belum saya bangun menjadi AAB karena lingkungan saya tidak punya Android SDK dan internet. Skrip patch sudah saya uji pada contoh build.gradle.

## Membuat APK lewat GitHub (tanpa Android Studio)
Berkas yang dipakai: ZIP ini (`dzikr-play-project.zip`), bukan `dzikr-app.zip` dan bukan file HTML.
1. Buat repository baru di GitHub (disarankan Private).
2. Ekstrak ZIP, lalu unggah ISI folder `dzikr-play` (www, android-config, scripts, store, capacitor.config.json, package.json, .github, dan lainnya) ke repository, di cabang `main`. Jangan unggah file ZIP-nya.
   Jika folder `.github` tidak ikut terunggah: di GitHub pilih Add file > Create new file, ketik nama `.github/workflows/build-apk.yml`, lalu tempel isi `github-actions/build-apk.yml`. Ulangi untuk `release-aab.yml`.
3. Buka tab Actions > "Build APK debug" > Run workflow. Tunggu sekitar 5-10 menit.
4. Setelah hijau, buka run tersebut, bagian Artifacts, unduh `dzikr-debug-apk` (ZIP berisi app-debug.apk). Ekstrak dan pasang di HP (izinkan instal dari sumber tidak dikenal). APK debug ini untuk uji coba, bukan untuk Play Store.
5. Untuk Play Store (AAB bertanda tangan): buat keystore sekali di komputer (`scripts/create-keystore`), ubah menjadi teks base64 (Linux/Mac: `base64 -w0 dzikr-release.jks`; Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("dzikr-release.jks"))`). Di GitHub: Settings > Secrets and variables > Actions, buat 4 secret: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD. Lalu jalankan Actions > "Release AAB bertanda tangan" dan isi versionCode (naik tiap rilis). Unduh artefak `dzikr-release-aab` dan unggah ke Play Console.
Catatan: alur GitHub ini belum bisa saya jalankan dari sini (tidak ada internet), hanya sintaks YAML yang saya periksa. Jika build gagal, salin pesan error dari log Actions dan kirim ke saya. Jika kegagalan berasal dari plugin pembayaran, hapus `cordova-plugin-purchase` dari baris npm install di berkas workflow dulu (donasi Play akan menampilkan "belum tersedia").
Jaga kerahasiaan keystore dan password: jangan unggah file .jks ke repository (sudah masuk .gitignore).
