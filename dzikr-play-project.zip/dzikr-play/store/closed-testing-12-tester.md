# Pengujian tertutup: 12 tester selama 14 hari

Berlaku untuk akun developer PRIBADI yang dibuat setelah 13 November 2023: sebelum mengajukan akses produksi, aplikasi harus diuji tertutup oleh minimal 12 tester yang bergabung (opt-in) selama 14 hari berturut-turut. Akun organisasi biasanya tidak diwajibkan. Cek syarat terbaru di Play Console (halaman Dasbor).

## Langkah
1. Play Console > Pengujian > Pengujian tertutup > Buat track. Unggah AAB.
2. Buat daftar penguji: pakai Google Group atau daftar email Gmail. Kumpulkan 15-20 orang agar aman bila ada yang keluar.
3. Bagikan tautan "Gabung pengujian" (opt-in) ke tester. Mereka harus: klik tautan, tekan "Jadi penguji", lalu pasang aplikasi dari Play Store.
4. Pastikan jumlah tester yang aktif tetap 12 atau lebih selama 14 hari penuh. Minta mereka membuka aplikasi minimal beberapa kali.
5. Kumpulkan masukan (Google Form). Perbaiki bug, lalu unggah versi baru ke track yang sama bila perlu.
6. Setelah 14 hari, klik "Ajukan akses produksi" dan jawab kuesionernya: bagaimana Anda merekrut tester, masukan yang didapat, perbaikan yang dibuat.

## Pesan undangan (salin dan sesuaikan)
Assalamu'alaikum. Mohon bantuannya menjadi penguji aplikasi dzikir "Dzikr" (tasbih digital, Asmaul Husna, doa harian). Cukup 3 langkah: (1) buka tautan ini: [TAUTAN OPT-IN], (2) tekan "Jadi penguji", (3) pasang aplikasinya dan coba dipakai beberapa kali selama 2 minggu. Jangan keluar dari pengujian sampai [TANGGAL SELESAI]. Masukan boleh dikirim lewat: [TAUTAN FORM]. Jazakumullahu khairan.

## Yang perlu diuji tester
Tasbih dan target, mode khusyuk, dzikir sendiri, Istiqomah, 99 nama + tombol Dengarkan dan rekaman, doa + Doaku + cari, pengingat, mode gelap, layar landscape, tombol kembali.
