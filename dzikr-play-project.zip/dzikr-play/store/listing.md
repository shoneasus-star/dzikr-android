# Detail toko (Store listing)

## Bahasa Indonesia (utama)
**Nama aplikasi (maks 30):** Dzikr: Tasbih & Asmaul Husna

**Deskripsi singkat (maks 80):** Tasbih digital, 99 Asmaul Husna, doa harian, dan pengingat dzikir.

**Deskripsi lengkap (maks 4000):**
Dzikr adalah teman berdzikir sehari-hari: sederhana, rapi, dan bisa dipakai tanpa internet.

TASBIH DIGITAL
- Hitung dzikir dengan satu ketukan, lengkap dengan getar dan bunyi lembut (masing-masing bisa dimatikan)
- Target 33, 99, 100, atau 1000, dengan animasi saat target tercapai
- Mode khusyuk: layar gelap, hanya angka, ketuk di mana saja
- Tambahkan dzikir sendiri beserta keutamaannya, dan urutkan sesuai keinginan

ISTIQOMAH
- Pantau kebiasaan berdzikir harian: hari berturut-turut, 7 hari terakhir, dan rekor terbaik

99 ASMAUL HUSNA
- Tulisan Arab berharakat, latin, arti, dan sumber dari Al-Quran atau hadits
- Cari nama, tampilan grid atau daftar, simpan favorit
- Rekaman audio Asmaul Husna dengan tombol putar, jeda, dan berhenti

KUMPULAN DOA
- Doa pagi, doa sore, dan doa sehari-hari lengkap dengan lafadz berharakat, latin, arti, dan sumber
- Doaku: simpan doa pilihan Anda sendiri
- Cari doa dengan cepat

LAINNYA
- Pengingat dzikir pagi, sore, dan sebelum tidur
- Mode terang dan gelap, 7 pilihan warna, bahasa Indonesia dan English
- Dukungan sukarela untuk pengembang (opsional, lewat Google Play)
- Tanpa iklan, tanpa akun, tanpa pelacakan. Data tersimpan hanya di perangkat Anda

Catatan: teks ayat, hadits, dan doa disusun dari sumber yang dicantumkan. Mohon periksa kembali dengan mushaf atau guru yang Anda percaya, dan sampaikan koreksi lewat email pengembang.

**Kategori:** Gaya hidup (alternatif: Buku & Referensi)  **Tag:** dzikir, tasbih, asmaul husna, doa harian, islam
**Email kontak:** [ISI EMAIL ANDA]  **Situs web (opsional):** [ISI]  **URL Privacy Policy:** [ISI setelah dihosting]

## English (optional translation)
**Title:** Dzikr: Tasbih & Asmaul Husna
**Short:** Digital tasbih, 99 Names of Allah with audio, daily duas and dhikr reminders.
**Full:** Dzikr is a simple, clean daily companion for remembrance of Allah that works offline. Digital tasbih with targets, khushu mode, your own dhikr; an Istiqomah streak tracker; the 99 Names of Allah with vowelized Arabic, meaning, sources and audio; morning, evening and daily duas plus your own saved duas; reminders; light/dark modes and colors. No ads, no account, no tracking. Data stays on your device.

## Aset
- Ikon 512x512: `assets/icon-512.png`
- Grafis fitur 1024x500: `assets/feature-graphic-1024x500.png`
- Screenshot ponsel (minimal 2, disarankan 4-8): `screenshots/phone/`
