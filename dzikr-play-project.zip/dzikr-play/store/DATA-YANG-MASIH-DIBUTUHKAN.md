# Data yang masih Anda perlu sediakan agar bisa lulus Play Store

1. Email kontak publik (untuk Play Console, listing, dan Privacy Policy). Disarankan email khusus aplikasi.
2. Tipe akun developer (pribadi atau organisasi) dan tanggal pembuatannya. Ini menentukan wajib tidaknya 12 tester / 14 hari.
3. Nama developer yang akan tampil di Play Store (sekarang di dokumen: Sultan Suhendra) dan keperluan verifikasi identitas Google (dokumen identitas, alamat, nomor telepon).
4. URL publik Privacy Policy (unggah `store/privacy-policy.html` ke GitHub Pages / Netlify / situs Anda, lalu salin alamatnya).
5. Nama paket final. Saat ini com.sultansuhendra.dzikr. Tidak bisa diubah setelah rilis.
6. Keputusan donasi: build Play memakai donasi OFF (disarankan).
7. Keystore tanda tangan: buat sendiri dengan `scripts/create-keystore`, simpan file dan password dengan aman, cadangkan di dua tempat. Jangan dibagikan ke siapa pun, termasuk ke saya.
8. Screenshot dari HP Anda (opsional tetapi disarankan). Draft sudah ada; minimal 2, rasio 9:16, sisi 320-3840 px.
9. Daftar 12+ tester (alamat Gmail) bila diwajibkan.
10. Pembayaran pendaftaran akun Play Console US$25 (sekali bayar).
11. Pemeriksaan isi: cocokkan ayat, hadits, dan doa dengan mushaf/guru. Dua hal yang perlu perhatian: hadits "doa adalah senjata orang beriman" (sebagian ulama menilai sanadnya lemah) dan nomor-nomor hadits keutamaan dzikir.
12. Jika ingin font persis pratinjau: unduh Amiri, Fraunces, Nunito (OFL) dan pasang lewat @font-face.
