# Donasi yang sesuai kebijakan Google Play

## Aturannya (ringkas)
- Kebijakan Pembayaran Google Play melarang aplikasi mengarahkan pengguna ke metode pembayaran selain Google Play Billing untuk transaksi di dalam aplikasi. Karena itu kartu rekening BSI (transfer bank langsung) TIDAK boleh tampil di build Play. Di build Play kartu itu sudah disembunyikan.
- Donasi bebas-Play-Billing hanya untuk organisasi nirlaba berpajak-bebas yang sudah disetujui lewat formulir Google.
- Untuk pengembang perorangan (bukan organisasi nirlaba terdaftar), pesan resmi Google kepada pengembang lain menyebut dua pilihan: hapus fitur donasi, atau gunakan Google Play Billing saat menerima donasi. Build Play di paket ini memakai pilihan kedua.
- Tidak ada jaminan lolos: tinjauan Play dilakukan manual dan tafsirannya bisa berbeda. Pilihan paling aman tetap menghapus fitur donasi sama sekali (ubah tombol Donasi menjadi tersembunyi). Cek kebijakan terbaru di Play Console sebelum mengirim.

## Cara kerja di aplikasi
Di build Play, tombol Donasi di halaman Tentang membuka "Dukung Pengembang" dengan 4 nominal. Setiap nominal adalah produk dalam aplikasi sekali-beli (consumable) yang dibayar lewat Google Play. Aplikasi tidak memberi fitur khusus sebagai imbalan; ini murni dukungan sukarela.

## Yang perlu Anda siapkan di Play Console
1. Profil pembayaran (merchant) di Play Console: Setup > Payments profile.
2. Buat 4 produk dalam aplikasi (Monetize > Products > In-app products) dengan ID persis berikut, status Aktif:
   - dukung_10k  (mis. Rp10.000)
   - dukung_25k  (mis. Rp25.000)
   - dukung_50k  (mis. Rp50.000)
   - dukung_100k (mis. Rp100.000)
   Nama: "Dukungan Rp10.000" dst. Deskripsi: "Dukungan sukarela untuk pengembangan aplikasi Dzikr. Tidak membuka fitur apa pun."
3. Unggah AAB ke track pengujian, tambahkan akun Anda sebagai penguji lisensi (Settings > License testing), lalu coba beli di HP asli.
4. Biaya layanan Google berlaku atas setiap pembelian. Play Console akan menandai aplikasi "Berisi pembelian dalam aplikasi".
5. Plugin yang dipakai: `cordova-plugin-purchase` (sudah ada di perintah npm install). Kode pembayaran saya tulis mengikuti dokumentasi plugin dan diuji dengan tiruan plugin; BELUM diuji dengan pembayaran sungguhan karena butuh akun Play Console Anda. Jika setelah `cap sync` plugin tidak terbaca (tampil "Pembayaran Google Play belum tersedia"), kabari agar saya sesuaikan cara pemuatannya.

## Jika ingin tanpa donasi di Play
Di `www/index.html` cari tombol Donasi pada fungsi `openAbout` dan hapus baris tombol `id="dn"` beserta baris `$("#dn").onclick=...`. Lalu bangun ulang.

## Di luar Play (situs, PWA, APK langsung)
Versi HTML dan PWA tetap menampilkan kartu rekening BSI. Itu diperbolehkan karena tidak didistribusikan lewat Google Play.
