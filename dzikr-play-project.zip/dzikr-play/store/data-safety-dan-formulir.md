# Jawaban formulir Play Console

## Keamanan data (Data Safety)
- Apakah aplikasi mengumpulkan atau membagikan data pengguna yang diwajibkan? **TIDAK**
- Semua data hanya diproses di perangkat dan tidak dikirim keluar, jadi tidak dihitung "dikumpulkan".
- Enkripsi saat transit: tidak berlaku. Permintaan penghapusan data: tidak berlaku (data hanya lokal).
- Kondisi agar jawaban ini benar: build Play (`www/index.html`) tidak memuat Google Fonts, iklan, analitik, atau SDK. Jika Anda menambahkannya, perbarui formulir.
- Izin Android: `INTERNET` (bawaan Capacitor), `VIBRATE` (getar tasbih, dari plugin haptics), dan `BILLING` (ditambahkan plugin pembayaran). Semuanya izin biasa tanpa dialog. Periksa `android/app/src/main/AndroidManifest.xml` setelah `cap add android` dan jangan tambah izin lain selain yang disebut.

## Tombol WhatsApp (Kritik dan saran)
Tombol di halaman Tentang hanya membuka tautan wa.me ke nomor pengembang di aplikasi WhatsApp/peramban pengguna. Aplikasi tidak mengirim data apa pun sendiri. Nomor yang tampil di aplikasi adalah nomor yang Anda pilih untuk publik; pertimbangkan memakai nomor khusus aplikasi.

## Rating konten (IARC)
Kategori: Referensi/Utilitas. Jawab TIDAK untuk: kekerasan, darah, seksual/ketelanjangan, bahasa kasar, zat terlarang, perjudian, konten buatan pengguna yang dibagikan, berbagi lokasi, pembelian digital. Hasil yang diharapkan: untuk semua usia (3+/Everyone). Isi sendiri kuesioner di Console; jangan mengubah jawaban agar jujur sesuai fitur.

## Target audiens
Pilih **13 tahun ke atas** (atau 18+). Hindari memilih anak di bawah 13 agar tidak terkena persyaratan Kebijakan Keluarga.

## Deklarasi lain
- Akses aplikasi: semua fitur tanpa login. Iklan: tidak ada. Aplikasi pemerintah: tidak. Fitur keuangan: tidak ada (dukungan sukarela memakai Google Play Billing). Kesehatan: tidak. Berita: tidak. ID iklan: tidak dipakai.
- Konten buatan pengguna: pengguna hanya mencatat dzikir/doa untuk dirinya sendiri di perangkat, tidak dibagikan, jadi kebijakan UGC tidak berlaku.

## Soal donasi (penting)
Lihat `donasi-google-play.md`. Build Play memakai Google Play Billing (pembayaran diproses Google), bukan transfer bank di dalam aplikasi. Pembayaran tidak diterima atau disimpan oleh aplikasi, jadi tidak ada data keuangan yang Anda kumpulkan. Tetap cek halaman Keamanan data di Console untuk memastikan tidak ada pertanyaan baru yang muncul. Jika Anda memilih menghapus fitur donasi, abaikan bagian ini.
