@echo off
cd /d "%~dp0\.."
if not exist keystore.properties (echo Belum ada keystore.properties & exit /b 1)
call npx cap sync android || exit /b 1
if "%VERSION_CODE%"=="" set VERSION_CODE=1
if "%VERSION_NAME%"=="" set VERSION_NAME=1.0.0
node android-config\patch-android.js || exit /b 1
cd android && call gradlew.bat bundleRelease
echo Selesai: android\app\build\outputs\bundle\release\app-release.aab
