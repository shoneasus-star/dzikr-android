#!/usr/bin/env bash
# Membuat kunci unggah (upload key). SIMPAN file .jks dan password di tempat aman + cadangan.
keytool -genkeypair -v -storetype PKCS12 -keystore dzikr-release.jks -alias dzikr -keyalg RSA -keysize 2048 -validity 10000
echo "Lalu salin android-config/keystore.properties.example menjadi keystore.properties dan isi passwordnya."
