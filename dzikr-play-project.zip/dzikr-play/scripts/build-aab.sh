#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
if [ ! -f keystore.properties ]; then echo "Belum ada keystore.properties (lihat android-config/keystore.properties.example)"; exit 1; fi
npx cap sync android
VERSION_CODE=${VERSION_CODE:-1} VERSION_NAME=${VERSION_NAME:-1.0.0} node android-config/patch-android.js
cd android && ./gradlew bundleRelease
echo "Selesai: android/app/build/outputs/bundle/release/app-release.aab"
