@echo off
keytool -genkeypair -v -storetype PKCS12 -keystore dzikr-release.jks -alias dzikr -keyalg RSA -keysize 2048 -validity 10000
echo Lalu salin android-config\keystore.properties.example menjadi keystore.properties dan isi passwordnya.
