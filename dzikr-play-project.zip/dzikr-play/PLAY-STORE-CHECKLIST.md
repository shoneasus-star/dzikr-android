# Checklist Publikasi Dzikr ke Google Play (status per 15 November 2026)

Keterangan: SELESAI = sudah dikerjakan di paket ini. SIAP = bahan/skrip sudah ada, tinggal Anda jalankan. BUTUH ANDA = hanya Anda yang bisa mengerjakan.

| # | Item | Status | Keterangan |
|---|------|--------|------------|
| 1 | Memeriksa seluruh fitur aplikasi | SELESAI (otomatis) | 60 uji otomatis di Chromium lulus semua: dzikir, tasbih, khusyuk, istiqomah, dzikir sendiri, 99 nama, rekaman, doa, Doaku, cari doa, pengaturan, pengingat, tentang, layar landscape. Masih perlu uji di HP asli (lihat bagian "Uji di HP asli"). |
| 2 | Memperbaiki bug dan error | SELESAI | Tombol Dengarkan diperbaiki (cadangan rekaman bila HP tanpa suara Arab), tombol Kembali halaman Tentang pindah ke kanan atas, pop up muat di layar kecil/landscape, nomor tumpang tindih, tombol target tasbih, kedip layar tasbih. Tidak ada error JavaScript saat uji. Total 87 uji otomatis lulus (60 fitur + 27 untuk bahasa, getar, Dengarkan, donasi Play), ditambah uji khusus jembatan getar, mode khusyuk, notifikasi suara/getar, dan tombol WhatsApp. |
| 3 | File AAB bertanda tangan digital | SIAP | Belum dibangun di sini (tidak ada Android SDK/internet). Skrip: `scripts/create-keystore` lalu `scripts/build-aab` (otomatis target API 36, izin getar, tanda tangan). BUTUH ANDA: membuat keystore dan menjalankan build. |
| 4 | Ikon aplikasi 512 x 512 | SELESAI | `store/assets/icon-512.png` |
| 5 | Screenshot resmi Play Store | DRAFT SIAP | 8 screenshot 1080x1920 di `store/screenshots/phone/` dari aplikasi sungguhan. Ditangkap di komputer dengan font cadangan; disarankan ambil ulang dari HP Anda. Grafis fitur 1024x500 (wajib) juga sudah dibuat. |
| 6 | Deskripsi aplikasi | SELESAI | `store/listing.md` (Indonesia + Inggris). |
| 7 | Halaman Privacy Policy | SELESAI (perlu diisi dan dihosting) | `store/privacy-policy.html`. BUTUH ANDA: isi email kontak, unggah ke alamat publik (HTTPS), tempel URL di Play Console. |
| 8 | Formulir Data Safety | SIAP | Jawaban lengkap di `store/data-safety-dan-formulir.md`. BUTUH ANDA: mengisinya di Play Console. |
| 9 | Pengujian 12 tester selama 14 hari | SIAP | Panduan + pesan undangan di `store/closed-testing-12-tester.md`. BUTUH ANDA: 12 tester nyata. |
| 10 | Mengajukan aplikasi ke Google Play | SIAP | Urutan langkah di bawah. BUTUH ANDA: akun developer, verifikasi identitas, klik kirim. |

## Hal penting yang bisa membuat ditolak
1. **Donasi.** Transfer bank/kartu rekening di dalam aplikasi melanggar kebijakan Pembayaran Play, jadi di build Play kartu BSI disembunyikan dan diganti "Dukung Pengembang" lewat Google Play Billing (4 produk dalam aplikasi, lihat `store/donasi-google-play.md`). Belum teruji dengan pembayaran sungguhan, dan tidak ada jaminan lolos tinjauan; cara paling aman adalah tanpa donasi. Versi HTML/PWA di luar Play tetap menampilkan kartu BSI.
2. **Target API 36 (Android 16).** Sejak 31 Agustus 2026 aplikasi baru wajib menargetkan API 36. `android-config/patch-android.js` mengatur ini otomatis; pakai Android Studio terbaru dengan SDK 36 dan `@capacitor/android` versi terbaru.
3. **Akun pribadi baru wajib closed test 12 tester / 14 hari** sebelum bisa merilis ke produksi (item 9).
4. **Konten keagamaan** (ayat, hadits, doa) tidak dilarang, tetapi pastikan teksnya benar; kesalahan yang dilaporkan pengguna bisa memicu keluhan. Cocokkan dengan mushaf/guru Anda.
5. **Nama paket** (`com.sultansuhendra.dzikr`) tidak bisa diubah setelah dirilis. Ganti di `capacitor.config.json` sebelum `cap add android` bila ingin yang lain.

## Urutan langkah
1. Daftar akun Google Play Console (biaya sekali bayar US$25) dan selesaikan verifikasi identitas.
2. Buat keystore: `scripts/create-keystore.sh` (atau .bat). Cadangkan file .jks dan password di dua tempat.
3. `npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/app @capacitor/haptics cordova-plugin-purchase` lalu `npx cap add android`.
4. `scripts/build-aab.sh` (atau .bat). Hasil: `android/app/build/outputs/bundle/release/app-release.aab`. Setiap rilis baru naikkan `VERSION_CODE`.
5. Play Console > Buat aplikasi. Isi: Detail toko (listing.md, ikon, grafis fitur, screenshot), Privacy Policy URL, Keamanan data, Rating konten, Target audiens, Deklarasi aplikasi.
6. Rilis > Pengujian > Pengujian tertutup: unggah AAB, tambah 12+ tester, jalankan 14 hari berturut-turut.
7. Setelah syarat terpenuhi, ajukan "Akses produksi", lalu buat rilis produksi dan kirim untuk ditinjau (biasanya beberapa hari).

## Uji di HP asli sebelum dikirim (tidak bisa dilakukan dari sini)
- Tombol Dengarkan di pop up nama (suara Arab bila terpasang; bila tidak, rekaman diputar dari sekitar nama itu).
- Getar saat mengetuk tasbih, bunyi gelembung, mode khusyuk, tombol Kembali Android (menutup pop up lebih dulu).
- Putar layar ke landscape di tasbih dan pop up Asmaul Husna.
- Android 16 (gestur kembali prediktif) dan satu HP layar kecil.
